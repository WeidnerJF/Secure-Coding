// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

bool do_even_more_custom_application_logic()
{
  // TODO: Throw any standard exception

  std::cout << "Running Even More Custom Application Logic." << std::endl;
  throw std::exception("Exception has Occured");
  return true;
}
void do_custom_application_logic()
{
  // TODO: Wrap the call to do_even_more_custom_application_logic()
  //  with an exception handler that catches std::exception, displays
  //  a message and the exception.what(), then continues processing
  std::cout << "Running Custom Application Logic." << std::endl;
  
  try {
      if (do_even_more_custom_application_logic())
      {
          std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
      }
  }
  catch (std::exception) {
      std::cout << "Exception occured" << std::endl;

  }
  // TODO: Throw a custom exception derived from std::exception
  //  and catch it explictly in main
  // logic error exception thrown
  throw std::logic_error("exception occured");
 
  std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
  // TODO: Throw an exception to deal with divide by zero errors using
  //  a standard C++ defined exception
    if (den == 0) {
        throw std::runtime_error("divided by zero"); // runtime error due to dividing by zero
    }
  return (num / den);
}

void do_division() noexcept
{
  //  TODO: create an exception handler to capture ONLY the exception thrown
  //  by divide.

  float numerator = 10.0f;
  float denominator = 0;
  float result = 0; // create and initialized result as variable rather then using auto
  try {
      result = divide(numerator, denominator);
      std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  // catch and error message for runtime error
  catch (std::runtime_error) {
      std::cout << "Runtime error exception has occured" << std::endl;
  }
  
}

int main()
{
  std::cout << "Exceptions Tests!" << std::endl;

  // TODO: Create exception handlers that catch (in this order):
  //  your custom exception
  //  std::exception
  //  uncaught exception 
  //  that wraps the whole main function, and displays a message to the console.
    
  //exception handler and catch begins
  try {
      do_division();
      do_custom_application_logic();
  }
  //custom exception for logic error
  catch (std::logic_error) {
      std::cout << "logic error occured";

  }
  //standard exception
  catch (std::exception) {
      std::cout << "Standard exception has occured" << std::endl;
  }
  // uncaught exceptions
  catch (...) {
      std::cout << "uncaught exception hass occured" << std::endl;
  }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
